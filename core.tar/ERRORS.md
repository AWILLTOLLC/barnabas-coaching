# ERRORS.md - Anti-Repeat System

_Every mistake logged here is a mistake that doesn't have to happen twice. Be specific. Unlogged mistakes repeat._

---

## Format

```
### [YYYY-MM-DD] What went wrong (short title)
**What happened:** Description of the mistake
**Why it happened:** Root cause
**Correct pattern:** What to do instead
**Prevention rule:** One-line rule to remember
```

---

## Log

_Nothing here yet. First mistake incoming eventually._
