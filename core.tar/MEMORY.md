# MEMORY.md - Long-Term Memory

_Curated context that persists across sessions. Raw logs live in memory/YYYY-MM-DD.md._

---

## About Aaron

- Based in Seattle, WA (PST / UTC-8) — moving to Fremont neighborhood soon
- Selling house, expecting $300–500k proceeds + ~$400k retirement
- House sale plan: clean sale, 3–5 month timeline (5 months conservative)
- First sale fell through (buyer budget). Decided against Airbnb — not worth the management overhead
- Pre-sale work needed: ~$10k downstairs bathroom remodel (non-functional, needs full shower, flooring, wall repair, sink, toilet, vanity), plus lighter work Aaron will DIY
- Bathroom contractor outreach (2026-02-25): **Eagle Remodel & Construction** (Doru, Everett WA, (206) 495-8587) — quote pending. Backups: Footprints Bath and Tile Northwest (Everett), SMY Home Improvement (Lynnwood)
- Anton (realtor friend) is advising on the sale
- House layout: main floor + unfinished walkout basement + upstairs MIU suite (separate entrance). Hot tub on ground floor.
- Capital deployment: next phase of business and life
- Deep work person — quality hours matter more than quantity; guards work/life balance seriously
- Rides his BMW R 1200 GS to work most days. Also has a 1997 F350 "Blue."
- Works out with trainer Dan (Mon/Fri) + Olympic Athletic Club 2 other days with Lily

## Lily
- Aaron's girlfriend, cherished deeply
- Co-founder of Glimmer Cards with Aaron
- Works out together, goes to raves/events together
- Treat Lily as a significant presence in all life planning

## The Three Businesses
1. **IT Consulting** — biotech clients, primary income; AI Coach service being considered
2. **Black Raven Company** — handmade scotch eye augers (bushcraft/green woodworking), wants to grow. Active manufacturer search in progress (2026-03-01): RFQ at `/root/.openclaw/workspace/BlackRavenAuger_RFQ.docx`, contact email claude@kaw.cc (August), target 1,500–2,000 units @ $8–15/unit, non-China preferred (Taiwan, India, Vietnam, Mexico, Eastern Europe, USA). Previous Chinese factory had communication failures. QIMA pre-shipment QC planned. Task tracked at `tasks/blackraven-rfq/todo.md`.
3. **Glimmer Cards** (with Lily) — rave compliment cards, brand new, wants to grow

## Merkle and Bloom (S-corp)
- Aaron's S-corp, used as the umbrella for game dev and possibly other ventures
- Has an EIN; DUNS number requested through Apple's flow (2026-02-21) — awaiting approval
- First iOS game: **Morse Code Defense** — asteroid-style arcade game that teaches Morse code via the Koch method. Hear the sound of a letter, type the key to destroy the asteroid. Boss fights, 5 zones, 10 levels each, power-ups. Published to TestFlight 2026-02-21.
- Target audiences: ham radio community, preppers, survivalists, military/veteran crowd

## Morse Code Defense — Marketing Automation Plan (2026-02-27)
Aaron wants Dru to drive app marketing post-launch. Modeled after how OpenClaw agent "Eddie" runs B2C app marketing at scale. Plan:
- **Content factory:** Generate short-form hooks ("hear this sound, what letter?") for TikTok/Instagram/YouTube Shorts/X, 3x/day, auto-posted via Postbridge or Buffer
- **Influencer outreach:** Find ham radio YouTubers, prepper channels, military/vet accounts via X API + browser; scrape emails; blast outreach at scale; Aaron approves deals
- **Daily KPI reports:** Morning Telegram message — downloads, revenue, top traffic sources
- **Customer support triage:** Handle App Store reviews and support emails; escalate only what matters
- **Setup needed:** Postbridge/Buffer account, App Store Connect API access, social accounts for Morse Command (X, TikTok, Instagram, YouTube), outbound email for influencer outreach
- Pre-launch: build content library + 50-influencer target list while app finishes

## OpenClaw Native App (Design Vision)
- Aaron and Dru designed a native macOS + iOS chat client (2026-02-24) — motivated by Telegram timeout/transparency problem
- Discord rejected: cleartext, Discord reads all content
- Vision: direct encrypted connection to gateway (mTLS, TLS + cert pinning, content-free APNs push)
- macOS: 3-pane layout (sidebar / chat / live task board). iOS: alert-first, approval flows, agent panel on swipe-up
- WireGuard built-in + Tailscale/Headscale first-class; OpenClaw Relay as paid fallback
- Features designed: Timeline Replay, Agent Roster, Artifact Library, Steer Controls, Approval Flows, Watch app
- Stack: Swift + SwiftUI, WebSocket, encrypted SQLite, Keychain, CryptoKit
- Not yet built — design/vision stage

## My Role
- Chief of staff, coordinator, right hand
- Lead an agent team Aaron is building
- Advisor on his AI Coach service offering

## Preferences & Tastes
- Raves, EDM, concerts/festivals
- Joule restaurant (Seattle fave), Stampede cocktail club
- Measured, intentional, balanced approach to everything

## X (Twitter) API
- Full API access set up 2026-02-27 — credentials in `/root/.openclaw/credentials/x_api.json`
- Bearer token + OAuth 1.0a (consumer key/secret + access token/secret), authorized as `@AlricEdryk`
- Can read any public tweet including full X Article body (plain_text field) via user context
- Use `requests-oauthlib` — see TOOLS.md for code snippet

## Infrastructure
- **Tailscale** installed on Aaron's OpenClaw instance (ubuntu-ct) — set up 2026-02-23
- Aaron uses Tailscale for remote access; iOS app connectivity over cellular routes through Tailscale
- **Nightly memory cron** running — ID: 2a848c7f-2d2c-4e73-8dfe-d7adc248cb72, fires 11pm PST, consolidates daily notes → MEMORY.md
- **OpenClaw Studio** (web UI): Aaron is setting this up on his Mac (2026-03-02), connecting to the gateway on ubuntu-ct via `wss://ubuntu-ct.tailb4a099.ts.net`. Requires Studio's custom Node server (not `next dev`) running on the Mac at `HOST=0.0.0.0` so browser can reach it via Tailscale IP (`100.94.67.96:3000`). Upstream URL in Studio settings must point to `wss://ubuntu-ct.tailb4a099.ts.net`, not localhost. Work-in-progress — may need revisiting.

## About Me (Dru)
- Name: Dru
- Wizard energy 🧙
- Came online 2026-02-20
- Bootstrapped fresh with Aaron — he came prepared with his own SOUL.md and IDENTITY.md
- **SOUL.md updated 2026-02-27** with sharpened operating rules: brevity is law, strong opinions required (no hedging), swearing permitted when it earns it, banned opener phrases, Advanced Operating Principles section added (orchestrator role, agent spawning, safety exception gate, self-evolution with approval, 24/7 mode). This is the current canonical SOUL.
